#import "SceneDelegate.h"
#import "HelloWorldViewController.h"

@implementation SceneDelegate

- (void)scene:(UIScene *)scene
    willConnectToSession:(UISceneSession *)session
                 options:(UISceneConnectionOptions *)connectionOptions {
    if (![scene isKindOfClass:[UIWindowScene class]]) {
        return;
    }

    NSLog(@"[启动] 4. SceneDelegate：创建窗口、导航容器和首页");

    // ③ UIWindow：承载整个界面的窗口，并归属于当前 UIWindowScene。
    UIWindow *window = [[UIWindow alloc] initWithWindowScene:(UIWindowScene *)scene];

    // ④ 导航容器：统一管理原生页面和 RN 页面，提供导航栏与系统返回按钮。
    HelloWorldViewController *helloWorld = [[HelloWorldViewController alloc] init];
    UINavigationController *navigationController =
        [[UINavigationController alloc] initWithRootViewController:helloWorld];

    window.rootViewController = navigationController;
    self.window = window;
    [window makeKeyAndVisible];
}

- (void)sceneWillEnterForeground:(UIScene *)scene {
    NSLog(@"[生命周期] SceneDelegate：界面即将进入前台");
}

- (void)sceneDidBecomeActive:(UIScene *)scene {
    NSLog(@"[生命周期] SceneDelegate：界面已活跃，可以响应用户操作");
}

- (void)sceneWillResignActive:(UIScene *)scene {
    NSLog(@"[生命周期] SceneDelegate：界面即将暂停响应用户操作");
}

- (void)sceneDidEnterBackground:(UIScene *)scene {
    NSLog(@"[生命周期] SceneDelegate：界面已进入后台");
}

- (void)sceneDidDisconnect:(UIScene *)scene {
    NSLog(@"[生命周期] SceneDelegate：系统断开界面场景");
}

@end
