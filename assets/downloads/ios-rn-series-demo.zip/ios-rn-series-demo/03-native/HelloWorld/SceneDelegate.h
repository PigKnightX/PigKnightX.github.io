#import <UIKit/UIKit.h>

// 一个 Scene 表示 App 的一个界面场景。本 Demo 只允许一个场景。
@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

// 窗口需要被强引用，才能在场景显示期间一直存在。
@property (nonatomic, strong) UIWindow *window;

@end
