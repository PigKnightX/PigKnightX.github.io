// HelloWorldViewController.m
#import "HelloWorldViewController.h"
#import "SecondViewController.h"

@implementation HelloWorldViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"iOS 学习 Demo";
    self.view.backgroundColor = UIColor.systemBackgroundColor;

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Hello World";
    titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleLargeTitle];
    titleLabel.adjustsFontForContentSizeCategory = YES;
    titleLabel.numberOfLines = 0;

    UILabel *descriptionLabel = [[UILabel alloc] init];
    descriptionLabel.text = @"这是一个原生 UIKit 页面。点击按钮，进入第二页。";
    descriptionLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    descriptionLabel.adjustsFontForContentSizeCategory = YES;
    descriptionLabel.numberOfLines = 0;
    descriptionLabel.textColor = UIColor.secondaryLabelColor;

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"打开第二页" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [button addTarget:self
               action:@selector(openSecondPage)
     forControlEvents:UIControlEventTouchUpInside];

    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    descriptionLabel.translatesAutoresizingMaskIntoConstraints = NO;
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:titleLabel];
    [self.view addSubview:descriptionLabel];
    [self.view addSubview:button];

    UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.topAnchor constraintEqualToAnchor:safe.topAnchor constant:48],
        [titleLabel.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor constant:24],
        [titleLabel.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor constant:-24],
        [descriptionLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:16],
        [descriptionLabel.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [descriptionLabel.trailingAnchor constraintEqualToAnchor:titleLabel.trailingAnchor],
        [button.topAnchor constraintEqualToAnchor:descriptionLabel.bottomAnchor constant:32],
        [button.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [button.trailingAnchor constraintEqualToAnchor:titleLabel.trailingAnchor],
        [button.heightAnchor constraintEqualToConstant:48]
    ]];
}

- (void)openSecondPage {
    SecondViewController *second = [[SecondViewController alloc] init];
    [self.navigationController pushViewController:second animated:YES];
}

@end
