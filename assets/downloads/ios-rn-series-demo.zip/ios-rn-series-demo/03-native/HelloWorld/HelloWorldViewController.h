#import <UIKit/UIKit.h>

// 一个页面的管理者：管理 view 及页面出现、消失等生命周期。
@interface HelloWorldViewController : UIViewController
@end
