#import <UIKit/UIKit.h>
#import "AppDelegate.h"

// ① 程序入口：把 App 交给 UIKit 管理，并指定应用级委托对象。
int main(int argc, char *argv[]) {
    @autoreleasepool {
        NSLog(@"[启动] 1. main：启动 UIKit");
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
