#import <UIKit/UIKit.h>

// AppDelegate 负责整个 App 的生命周期；窗口交给 SceneDelegate 管理。
@interface AppDelegate : UIResponder <UIApplicationDelegate>
@end
