#import <UIKit/UIKit.h>

// 第二页有自己的 ViewController，负责创建和管理自己的界面。
@interface SecondViewController : UIViewController
@end
