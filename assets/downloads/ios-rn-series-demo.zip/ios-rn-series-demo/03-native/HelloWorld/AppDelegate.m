#import "AppDelegate.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // ② App 级初始化放在这里，例如配置日志、网络等公共服务。
    NSLog(@"[启动] 2. AppDelegate：App 启动完成，准备连接界面场景");
    return YES;
}

- (UISceneConfiguration *)application:(UIApplication *)application
    configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession
                                   options:(UISceneConnectionOptions *)options {
    // 配置名与 Info.plist 一致；其中指定了 SceneDelegate 这个类。
    NSLog(@"[启动] 3. AppDelegate：选用 Default Configuration 场景配置");
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration"
                                        sessionRole:connectingSceneSession.role];
}

- (void)application:(UIApplication *)application
    didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // 这里只需记录；有场景持久化数据时，可在这里清理。
    NSLog(@"[生命周期] AppDelegate：系统丢弃了场景会话");
}

@end
