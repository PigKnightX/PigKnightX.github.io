#!/bin/bash
set -euo pipefail
command -v xcodebuild >/dev/null || { echo "请先安装完整 Xcode，并选择 Command Line Tools。"; exit 1; }
echo "本阶段仅使用 UIKit，无第三方依赖。打开 HelloWorld.xcodeproj 或执行 ./run.sh。"
