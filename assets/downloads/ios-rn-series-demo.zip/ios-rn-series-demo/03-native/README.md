# 原生 UIKit 骨架（第 1–3 篇）

Objective-C、Scene 生命周期、UIWindow、UINavigationController、两个原生 ViewController。页面通过 NSLayoutConstraint 排版。本阶段没有 CocoaPods、Masonry 或 RN。

## 环境与运行

需要 macOS、完整 Xcode、已安装的 iOS Simulator runtime。运行脚本还使用系统的 python3；App 的最低部署版本为 iOS 15.1。

```bash
open HelloWorld.xcodeproj
```

在 Xcode 选择 HelloWorld Scheme 和 iPhone 模拟器，按 Command-R。也可以使用脚本构建、安装和启动：

```bash
./run.sh
# 指定模拟器：
./run.sh 模拟器UDID
```

脚本优先选择已经启动的 iPhone 模拟器。构建日志保存在 build/build.log。可先执行 `xcrun simctl list devices available` 查询设备。

## 对照文章

- 第 1 篇：main.m → AppDelegate → UIKit 连接 SceneDelegate，后者建立窗口、导航控制器、首页。
- 第 2 篇：打开第二页按钮的 addTarget:action:forControlEvents:。
- 第 3 篇：两个页面的约束与 push/pop。增加生命周期日志后，区分页面隐藏和对象释放。

仅编译、不安装或启动 UI：

```bash
xcodebuild -project HelloWorld.xcodeproj -scheme HelloWorld \
  -configuration Debug -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO build
```
