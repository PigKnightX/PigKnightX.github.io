#!/bin/bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
cd "$PROJECT_DIR"
mkdir -p "$BUILD_DIR"
if [[ "${1:-}" == --help || "${1:-}" == -h ]]; then
    echo "用法：./run.sh [可选的 iOS 模拟器 UDID]"
    exit 0
fi
if [[ "$#" -gt 1 ]]; then echo "最多指定一个模拟器 UDID。"; exit 1; fi
for tool in xcodebuild xcrun python3; do
    command -v "$tool" >/dev/null || { echo "缺少命令：$tool"; exit 1; }
done
./setup.sh
xcrun simctl list devices available --json > "$BUILD_DIR/devices.json"
DEVICE_ID="$(python3 - "$BUILD_DIR/devices.json" "${1:-}" <<'PY'
import json
import re
import sys
with open(sys.argv[1]) as stream:
    groups = json.load(stream)['devices']
requested = sys.argv[2]
candidates = []
for runtime, devices in groups.items():
    if '.iOS-' not in runtime:
        continue
    version = tuple(map(int, re.findall(r'\d+', runtime.rsplit('iOS-', 1)[1])))
    for device in devices:
        if not device.get('isAvailable', False):
            continue
        if requested and device['udid'] == requested:
            print(requested)
            sys.exit(0)
        if not requested and device['name'].startswith('iPhone'):
            candidates.append((device['state'] == 'Booted', version, device['udid']))
if requested:
    sys.exit('指定的 iOS 模拟器不可用：' + requested)
if not candidates:
    sys.exit('没有可用的 iPhone 模拟器，请在 Xcode 中安装 iOS Simulator runtime。')
print(max(candidates)[2])
PY
)"
if [[ -d HelloWorld.xcworkspace ]]; then
    CONTAINER=(-workspace HelloWorld.xcworkspace)
else
    CONTAINER=(-project HelloWorld.xcodeproj)
fi
if ! xcodebuild "${CONTAINER[@]}" -scheme HelloWorld -configuration Debug \
    -destination "platform=iOS Simulator,id=$DEVICE_ID" \
    -derivedDataPath "$BUILD_DIR/DerivedData" CODE_SIGNING_ALLOWED=NO build \
    > "$BUILD_DIR/build.log" 2>&1; then
    tail -n 60 "$BUILD_DIR/build.log"
    exit 1
fi
XCODE_DEVELOPER_DIR="$(xcode-select -p)"
DEVICE_HUB="$XCODE_DEVELOPER_DIR/../Applications/DeviceHub.app"
if [[ -d "$DEVICE_HUB" ]]; then open "$DEVICE_HUB"; else open -a Simulator; fi
xcrun simctl bootstatus "$DEVICE_ID" -b
APP_PATH="$BUILD_DIR/DerivedData/Build/Products/Debug-iphonesimulator/HelloWorld.app"
xcrun simctl install "$DEVICE_ID" "$APP_PATH"
xcrun simctl launch --terminate-running-process "$DEVICE_ID" com.example.ioslearndemo
echo "已启动 HelloWorld：点击“打开第二页”验证 push，再点击“返回首页”验证 pop。"
