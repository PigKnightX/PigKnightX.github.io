# iOS 与 React Native 混合开发：系列示例

各阶段独立运行；先进入对应目录，按该目录 README 安装依赖。

| 目录 | 文章 | 内容 |
| --- | --- | --- |
| 03-native | 1–3 | Objective-C / UIKit / Scene / 原生 Auto Layout / 两页导航 |
| 04-dependencies | 4 | 相同页面改用 Masonry，演示 CocoaPods 与 workspace |
| 05-rn | 5–7 | 单入口 RN、原生容器、initialProperties、TurboModule、开发与离线构建 |
| 08-multiple | 8 | 两份完整 Bundle 与两个 Factory，分别打开 RN 页面 |
| 09-shared | 9 | 真实 Metro common + 业务增量包构建，以及 Node VM 模块语义验证 |

03-native 打开 HelloWorld.xcodeproj。04、05、08 先安装依赖，再打开 HelloWorld.xcworkspace；也可运行各目录 run.sh。05/08 固定 RN 0.88.1、React 19.3.0，最低 iOS 15.1；Node 版本范围见 package.json engines。本次构建环境为 Xcode 27.2、Node 22.22.0、CocoaPods 1.17.0。

Pods、node_modules、build、DerivedData、xcuserdata、本机 .xcode.env.local 不随源码分发。依赖锁文件随包保存，安装依赖需要网络。首次准备后请使用自己的 iPhone 模拟器运行。

09-shared 复用同级 08-multiple 安装的 JavaScript 依赖，不含可运行的 iOS 共享包加载器。它跳过 RN 原生启动，只验证 Metro 模块表、依赖 ID 和缓存语义。包体对比不能当作 Hermes、原生首屏或内存性能结论。第 8 阶段的独立 Factory 也没有共享同一个 JS Runtime。

所有阶段使用相同教学 App 标识 com.example.ioslearndemo。在同一模拟器安装不同阶段，会替换该示例 App。
