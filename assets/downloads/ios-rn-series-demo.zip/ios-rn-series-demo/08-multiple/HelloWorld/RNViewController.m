#import "RNViewController.h"
#import "RNHost.h"
#import <Masonry/Masonry.h>

@interface RNViewController ()
@property (nonatomic, copy) NSString *moduleName;
@property (nonatomic, copy) NSString *pageTitle;
@end

@implementation RNViewController

- (instancetype)init {
    return [self initWithModuleName:@"HelloRN" title:@"RN 页面"];
}

- (instancetype)initWithModuleName:(NSString *)moduleName
                              title:(NSString *)title {
    self = [super init];
    if (self) {
        _moduleName = [moduleName copy];
        _pageTitle = [title copy];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.pageTitle;
    self.view.backgroundColor = [UIColor systemBackgroundColor];

    // iOS → RN：NSDictionary 中的值会成为 React 根组件的 props。
    NSDictionary *initialProperties = self.moduleName == nil ||
        [self.moduleName isEqualToString:@"HelloRN"]
        ? @{
            @"greeting": @"你好，这是 iOS 传给 RN 的问候",
            @"source": @"HelloWorld · UIKit"
        }
        : @{
            @"featureName": @"拆包业务页",
        };
    UIView *reactView = [[RNHost sharedHost] viewWithModuleName:self.moduleName
                                           initialProperties:initialProperties];
    [self.view addSubview:reactView];

    // 原生导航栏继续由 UINavigationController 管理，RN 内容放在安全区域内。
    [reactView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        make.left.equalTo(self.view.mas_safeAreaLayoutGuideLeft);
        make.right.equalTo(self.view.mas_safeAreaLayoutGuideRight);
    }];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"[导航] RNViewController：RN 页面已显示");
}

- (void)dealloc {
    // 页面退出时释放这块 RN 视图；共享的 RNHost 留在 App 内供下次使用。
    NSLog(@"[导航] RNViewController：RN 页面容器已释放");
}

@end
