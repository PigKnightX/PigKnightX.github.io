#import "RNHost.h"
#import <React/RCTBundleURLProvider.h>
#import <React/RCTBundleManager.h>
#import <React/RCTDevMenu.h>
#import <React-RCTAppDelegate/RCTDefaultReactNativeFactoryDelegate.h>
#import <React-RCTAppDelegate/RCTReactNativeFactory.h>
#import <ReactAppDependencyProvider/RCTAppDependencyProvider.h>

// Factory 负责创建 RN 运行环境；Delegate 告诉它去哪里读取 JavaScript。
@interface DemoReactNativeDelegate : RCTDefaultReactNativeFactoryDelegate

@property (nonatomic, copy) NSString *entryFile;
@property (nonatomic, copy) NSString *bundleName;

- (instancetype)initWithEntryFile:(NSString *)entryFile
                        bundleName:(NSString *)bundleName;

@end

@implementation DemoReactNativeDelegate

- (instancetype)initWithEntryFile:(NSString *)entryFile
                        bundleName:(NSString *)bundleName {
    self = [super init];
    if (self) {
        _entryFile = [entryFile copy];
        _bundleName = [bundleName copy];
    }
    return self;
}

- (NSURL *)bundleURL {
#if DEBUG
    // 默认离线运行。需要 Fast Refresh 时，通过启动参数选择 Metro 模式。
    if ([[NSProcessInfo processInfo].environment[@"RN_USE_METRO"] isEqualToString:@"1"]) {
        NSLog(@"[RN] 从 Metro 加载 %@：localhost:8082", self.entryFile);
        // 固定本 Demo 的端口，服务未启动时也不会误连其他项目的 Metro。
        return [RCTBundleURLProvider jsBundleURLForBundleRoot:self.entryFile
                                               packagerHost:@"localhost:8082"
                                                  enableDev:YES
                                         enableMinification:NO
                                            inlineSourceMap:NO];
    }
#endif
    // 构建阶段会把两份 JS 和资源打包进 App，Debug 和 Release 都能离线打开。
    NSURL *url = [[NSBundle mainBundle] URLForResource:self.bundleName
                                         withExtension:@"jsbundle"];
    NSLog(@"[RN] 从 App 内的 %@.jsbundle 加载 JavaScript", self.bundleName);
    return url;
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge {
    return [self bundleURL];
}

@end

@interface RNHost ()
// 每份 bundle 使用独立 factory。一个 factory 创建 ReactHost 后，不能再切换到另一份 bundle。
@property (nonatomic, strong) DemoReactNativeDelegate *mainDelegate;
@property (nonatomic, strong) RCTReactNativeFactory *mainFactory;
@property (nonatomic, strong) DemoReactNativeDelegate *featureDelegate;
@property (nonatomic, strong) RCTReactNativeFactory *featureFactory;
@property (nonatomic, strong) RCTBundleConfiguration *mainBundleConfiguration;
@property (nonatomic, strong) RCTBundleConfiguration *featureBundleConfiguration;
@property (nonatomic, strong) RCTDevMenuConfiguration *mainDevMenuConfiguration;
@property (nonatomic, strong) RCTDevMenuConfiguration *featureDevMenuConfiguration;
@end

@implementation RNHost

+ (instancetype)sharedHost {
    static RNHost *host;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        host = [[RNHost alloc] init];
    });
    return host;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        // 离线演示不探测开发服务器；只有明确开启 Metro 时才允许访问。
        BOOL usesMetro = NO;
#if DEBUG
        usesMetro = [[NSProcessInfo processInfo].environment[@"RN_USE_METRO"] isEqualToString:@"1"];
#endif
        RCTBundleURLProviderAllowPackagerServerAccess(usesMetro);

        _mainDelegate = [[DemoReactNativeDelegate alloc] initWithEntryFile:@"index"
                                                                  bundleName:@"main"];
        _featureDelegate = [[DemoReactNativeDelegate alloc]
            initWithEntryFile:@"split-entry"
                   bundleName:@"feature"];
        // Codegen 生成的 provider 负责找到 NativeDemo 等原生模块。
        _mainDelegate.dependencyProvider = [[RCTAppDependencyProvider alloc] init];
        _featureDelegate.dependencyProvider = [[RCTAppDependencyProvider alloc] init];
        _mainFactory = [[RCTReactNativeFactory alloc] initWithDelegate:_mainDelegate];
        _featureFactory = [[RCTReactNativeFactory alloc] initWithDelegate:_featureDelegate];

        _mainBundleConfiguration = [self bundleConfigurationForDelegate:_mainDelegate];
        _featureBundleConfiguration = [self bundleConfigurationForDelegate:_featureDelegate];
#if DEBUG
        RCTDevMenuConfiguration *devMenu = [[RCTDevMenuConfiguration alloc]
            initWithDevMenuEnabled:usesMetro
              shakeGestureEnabled:usesMetro
         keyboardShortcutsEnabled:usesMetro];
        _mainDevMenuConfiguration = devMenu;
        _featureDevMenuConfiguration = [[RCTDevMenuConfiguration alloc]
            initWithDevMenuEnabled:usesMetro
              shakeGestureEnabled:usesMetro
         keyboardShortcutsEnabled:usesMetro];
#else
        _mainDevMenuConfiguration = [RCTDevMenuConfiguration defaultConfiguration];
        _featureDevMenuConfiguration = [RCTDevMenuConfiguration defaultConfiguration];
#endif
    }
    return self;
}

- (RCTBundleConfiguration *)bundleConfigurationForDelegate:
    (DemoReactNativeDelegate *)delegate {
    NSURL *bundleURL = [delegate bundleURL];
    if (bundleURL.isFileURL) {
        return [[RCTBundleConfiguration alloc] initWithBundleFilePath:bundleURL];
    }
    return [[RCTBundleConfiguration alloc]
        initWithPackagerServerScheme:@"http"
                  packagerServerHost:@"localhost:8082"
                          bundlePath:delegate.entryFile];
}

- (UIView *)viewWithModuleName:(NSString *)moduleName
            initialProperties:(NSDictionary *)initialProperties {
    BOOL isFeature = [moduleName isEqualToString:@"FeatureRN"];
    RCTReactNativeFactory *factory = isFeature ? self.featureFactory : self.mainFactory;
    RCTBundleConfiguration *bundleConfiguration =
        isFeature ? self.featureBundleConfiguration : self.mainBundleConfiguration;
    RCTDevMenuConfiguration *devMenuConfiguration =
        isFeature ? self.featureDevMenuConfiguration : self.mainDevMenuConfiguration;
    // 每份 bundle 使用自己的 factory；moduleName 必须和对应入口注册名一致。
    return [factory.rootViewFactory viewWithModuleName:moduleName
                                        initialProperties:initialProperties
                                            launchOptions:nil
                                      bundleConfiguration:bundleConfiguration
                                     devMenuConfiguration:devMenuConfiguration];
}

@end
