#import <UIKit/UIKit.h>

// 原生导航栈中的一个页面，里面的内容由 React Native 绘制。
@interface RNViewController : UIViewController

- (instancetype)initWithModuleName:(NSString *)moduleName
                              title:(NSString *)title;

@end
