# 多入口 RN 示例（第 8 篇）

原生首页包含第二页、HelloRN 和 FeatureRN 两个 RN 入口。每个 RN 入口使用独立 Factory 和完整 Bundle。

这是独立运行环境的演示，没有实现 common + business 的共享 Runtime 加载。

## 环境与运行

完整 Xcode、已安装的 iOS Simulator runtime、Node.js 22.13+（见 package.json engines）、npm、CocoaPods、python3。

```bash
./setup.sh
open HelloWorld.xcworkspace
./run.sh
```

在 Xcode 选 HelloWorld Scheme 和 iPhone 模拟器，按 Command-R。也可使用 `./run.sh --metro`（端口 8082）或 `./run.sh --release`。脚本编译、安装并启动模拟器 App。

`main.jsbundle` 对应 index.js → HelloRN；`feature.jsbundle` 对应 split-entry.js → FeatureRN。返回后再次打开会创建新根视图，Factory 留在进程中。

修改原生代码或离线 JS 后重新构建；修改 TurboModule spec 后重新执行 setup.sh。锁文件固定此次示例的依赖集合，安装仍需要联网。不要提交本机生成的 .xcode.env.local。

## 验证

```bash
npm run typecheck
./run.sh --release
```

查看 App 内两份 Bundle，以及分别进入两个入口后的参数、计数器和返回动作。公共包构建实验位于同级 09-shared 目录。
