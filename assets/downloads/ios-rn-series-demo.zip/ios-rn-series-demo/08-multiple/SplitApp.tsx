import React, {useState} from 'react';
import {Pressable, StyleSheet, Text, View} from 'react-native';

type SplitAppProps = {
  featureName?: string;
};

// 这个页面故意保持简单：它的重点是“来自另一份入口和另一份 bundle”。
export default function SplitApp({
  featureName = '拆包业务页',
}: SplitAppProps) {
  const [count, setCount] = useState(0);

  return (
    <View style={styles.page}>
      <Text style={styles.kicker}>FeatureRN · feature.jsbundle</Text>
      <Text style={styles.title}>{featureName}</Text>
      <Text style={styles.body}>
        这个页面来自 split-entry.js。它和 HelloRN 使用不同的 RN 入口，
        iOS 通过不同的 ReactNativeFactory 选择不同的 bundle。
      </Text>
      <View style={styles.diagram}>
        <Text style={styles.diagramLine}>iOS → RNHost → FeatureFactory</Text>
        <Text style={styles.diagramLine}>→ feature.jsbundle → SplitApp</Text>
      </View>
      <Pressable
        accessibilityRole="button"
        onPress={() => setCount(value => value + 1)}
        style={({pressed}) => [styles.button, pressed && styles.pressed]}>
        <Text style={styles.buttonText}>拆包页按钮：{count}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    padding: 24,
    backgroundColor: '#F3F5FA',
  },
  kicker: {
    marginTop: 12,
    color: '#7657D9',
    fontSize: 13,
    fontWeight: '700',
  },
  title: {
    marginTop: 10,
    color: '#17243A',
    fontSize: 32,
    fontWeight: '800',
  },
  body: {
    marginTop: 14,
    color: '#5B667A',
    fontSize: 16,
    lineHeight: 25,
  },
  diagram: {
    marginTop: 24,
    padding: 16,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E5EF',
  },
  diagramLine: {
    color: '#33476E',
    fontFamily: 'Menlo',
    fontSize: 12,
    lineHeight: 22,
  },
  button: {
    alignSelf: 'flex-start',
    marginTop: 24,
    paddingHorizontal: 18,
    paddingVertical: 13,
    borderRadius: 12,
    backgroundColor: '#7657D9',
  },
  pressed: {
    opacity: 0.7,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
});
