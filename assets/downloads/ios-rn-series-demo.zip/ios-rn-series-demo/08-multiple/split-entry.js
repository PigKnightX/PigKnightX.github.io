import {AppRegistry} from 'react-native';
import SplitApp from './SplitApp';

// 这是第二个 RN 入口。Xcode 会把它单独打成 feature.jsbundle。
AppRegistry.registerComponent('FeatureRN', () => SplitApp);
