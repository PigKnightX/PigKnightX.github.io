#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const ROOT = path.resolve(__dirname, '..');
// Reuse chapter 08's dependencies; override for a different local installation.
const DEMO = path.resolve(ROOT, process.env.RN_DEMO_ROOT || '../08-multiple');
if (!fs.existsSync(path.join(DEMO,'node_modules/metro/package.json'))) {
  throw Error('Install dependencies in ../08-multiple first, or set RN_DEMO_ROOT to an installed RN project.');
}
const requireDemo = require('node:module').createRequire(path.join(DEMO,'package.json'));
const Metro = requireDemo('metro');
const Server = requireDemo('metro/private/Server').default;
const {getDefaultConfig, mergeConfig} = requireDemo('@react-native/metro-config');
const out = path.join(ROOT, 'dist');
fs.mkdirSync(out, {recursive:true});
const commonPaths = new Set();
const ids = new Map();
const idPaths = new Map();
let phase = 'common';
let emitted = [];
function moduleId(file) {
  const logical = file.startsWith(DEMO + '/') ? 'demo/' + path.relative(DEMO,file) : 'experiment/' + path.relative(ROOT,file);
  if (!ids.has(logical)) {
    const id = crypto.createHash('sha256').update(logical).digest().readUInt32BE(0);
    if (idPaths.has(id) && idPaths.get(id)!==logical) throw Error('Module ID collision');
    ids.set(logical,id); idPaths.set(id,logical);
  }
  return ids.get(logical);
}
const config = mergeConfig(getDefaultConfig(ROOT), {
  projectRoot: ROOT,
  watchFolders: [ROOT, DEMO],
  maxWorkers: 2,
  resolver:{useWatchman:false,nodeModulesPaths:[path.join(DEMO,'node_modules')]},
  transformer:{babelTransformerPath:requireDemo.resolve('@react-native/metro-babel-transformer')},
  serializer:{
    createModuleIdFactory:() => moduleId,
    getModulesRunBeforeMainModule:() => phase==='common' ? [requireDemo.resolve('react-native/setup-env')] : [],
    getRunModuleStatement:(id,prefix='') => `/* SPLIT_START:${id} */${prefix}__r(${JSON.stringify(id)});`,
    processModuleFilter: module => {
      if (phase==='common') { commonPaths.add(module.path); emitted.push(module.path); return true; }
      const include = !commonPaths.has(module.path);
      if (include) emitted.push(module.path);
      return include;
    },
  },
});
const stats = {environment:{node:process.version,reactNative:requireDemo('react-native/package.json').version,react:requireDemo('react/package.json').version,metro:requireDemo('metro/package.json').version,platform:'ios',dev:false,minify:true}};
async function build(server,name,entry,modulesOnly) {
  emitted=[];
  const result = await server.build({...Server.DEFAULT_BUNDLE_OPTIONS,
    entryFile:path.join(ROOT,'entries',entry),platform:'ios',dev:false,minify:true,
    modulesOnly,runModule:true,excludeSource:true,
  });
  fs.writeFileSync(path.join(out,name),result.code);
  stats[name]={bytes:Buffer.byteLength(result.code),moduleDefinitions:(result.code.match(/(?:^|\n)__d\(/g)||[]).length};
  return {code:result.code,emitted:[...emitted]};
}
(async()=>{
  const server = await Metro.runMetro(config,{watch:false});
  try {
    const common = await build(server,'common.ios.jsbundle','common.js',false);
    phase='business';
    const home = await build(server,'home.ios.jsbundle','home.js',true);
    const profile = await build(server,'profile.ios.jsbundle','profile.js',true);
    const smoke = await build(server,'smoke.ios.jsbundle','smoke.js',true);
    for (const b of [home,profile,smoke]) {
      if (b.emitted.some(p=>commonPaths.has(p))) throw Error('Common modules duplicated');
      if (/__d\s*=/.test(b.code)) throw Error('Unexpected runtime prelude');
    }
    const withoutCommon = vm.createContext({console});
    let rejectedWithoutCommon = false;
    try { vm.runInContext(smoke.code,withoutCommon); } catch (error) { rejectedWithoutCommon = /__d is not defined/.test(error.message); }
    if (!rejectedWithoutCommon) throw Error('Business bundle unexpectedly ran without common');
    const context = vm.createContext({console});
    // Skip only common startup __r statements: RN needs native bindings unavailable in Node.
    // Definitions and Metro's actual __d/__r loader still run unmodified.
    const commonDefinitions = common.code.replace(/^\/\* SPLIT_START:\d+ \*\/[^\n]*$/gm,'');
    vm.runInContext(commonDefinitions,context,{filename:'common-definitions.js'});
    const requireBefore = context.__r;
    vm.runInContext(smoke.code,context,{filename:'smoke.jsbundle'});
    const shared = context.__smokeResult.shared;
    vm.runInContext(smoke.code,context,{filename:'smoke-again.jsbundle'});
    if(context.__r!==requireBefore || context.__sharedFactoryLoads!==1 || context.__smokeResult.shared!==shared || context.__smokeResult.text!=='Hello Metro') throw Error('Shared runtime semantic check failed');
    stats.smoke = {passed:true,rejectedWithoutCommon,sharedFactoryExecutions:context.__sharedFactoryLoads,sameMetroRequire:context.__r===requireBefore,text:context.__smokeResult.text,scope:'Node vm only; common RN startup omitted; NOT iOS/Hermes/UI verification'};
    // Full independent bundle baselines use the same IDs, transforms, minifier, and entries.
    phase='common';
    await build(server,'home.full.ios.jsbundle','home.js',false);
    await build(server,'profile.full.ios.jsbundle','profile.js',false);
    stats.comparison={independentBytes:stats['home.full.ios.jsbundle'].bytes+stats['profile.full.ios.jsbundle'].bytes,
      sharedBytes:stats['common.ios.jsbundle'].bytes+stats['home.ios.jsbundle'].bytes+stats['profile.ios.jsbundle'].bytes};
    stats.comparison.reductionPercent=Number((100*(1-stats.comparison.sharedBytes/stats.comparison.independentBytes)).toFixed(2));
    fs.writeFileSync(path.join(out,'stats.json'),JSON.stringify(stats,null,2)+'\n');
    fs.writeFileSync(path.join(out,'module-ids.json'),JSON.stringify(Object.fromEntries([...ids].sort()),null,2)+'\n');
    console.log(JSON.stringify(stats,null,2));
  } finally {await server.end();}
})().catch(error=>{console.error(error);process.exitCode=1});
