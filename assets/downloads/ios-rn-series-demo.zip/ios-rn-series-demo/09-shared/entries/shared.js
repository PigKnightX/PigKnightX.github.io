let loads = (globalThis.__sharedFactoryLoads || 0) + 1;
globalThis.__sharedFactoryLoads = loads;
module.exports = {identity: {}, greeting: name => `Hello ${name}`, loads};
