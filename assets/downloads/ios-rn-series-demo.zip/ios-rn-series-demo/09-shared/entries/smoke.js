const shared = require('./shared');
globalThis.__smokeResult = {text: shared.greeting('Metro'), shared, loads: shared.loads};
