const React = require('react');
const {AppRegistry} = require('react-native');
const shared = require('./shared');
globalThis.__splitCommonReady = {reactVersion: React.version, shared, AppRegistry};
