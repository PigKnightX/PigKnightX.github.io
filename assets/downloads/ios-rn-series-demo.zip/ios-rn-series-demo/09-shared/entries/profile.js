const React = require('react');
const {AppRegistry, View, Text} = require('react-native');
const shared = require('./shared');
function Profile() {
  return React.createElement(View, {style:{flex:1,alignItems:'center',justifyContent:'center'}},
    React.createElement(Text, null, shared.greeting('shared RN profile')));
}
AppRegistry.registerComponent('SplitProfile', () => Profile);
