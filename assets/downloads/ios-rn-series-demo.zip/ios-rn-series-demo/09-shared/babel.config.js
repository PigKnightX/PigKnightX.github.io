const path = require('node:path');
const {createRequire} = require('node:module');
const dependencyRoot = path.resolve(__dirname, process.env.RN_DEMO_ROOT || '../08-multiple');
const requireDemo = createRequire(path.join(dependencyRoot, 'package.json'));
module.exports = {presets: [requireDemo.resolve('@react-native/babel-preset')]};
