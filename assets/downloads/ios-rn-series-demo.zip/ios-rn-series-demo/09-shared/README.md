# 09-shared：Metro 公共包与业务包实验

本目录演示真正的 `common + business` 输出：公共包保留 Metro 模块系统、React、React Native 和共享模块；业务包只保留自身入口，引用公共包里已经定义的模块 ID。它是**构建与模块加载语义实验**，没有提供可运行的 iOS 工程，也没有完成 RN 0.88 新架构的原生追加包加载器。

## 运行

把本目录放在下载示例中的 `09-shared`，与 `08-multiple` 同级。先按 `08-multiple` 的 README 安装其 JavaScript 依赖，再执行：

```bash
cd 09-shared
node scripts/build-shared-bundles.cjs
```

不需要在此目录安装另一套依赖。脚本和 Babel 配置默认从 `../08-multiple/node_modules` 解析 Metro、React Native 与 Babel。也可以复用其他已经安装好同版本依赖的项目：

```bash
RN_DEMO_ROOT=/absolute/path/to/installed-rn-project node scripts/build-shared-bundles.cjs
```

`RN_DEMO_ROOT` 可以是绝对路径，也可以是相对于本目录的路径。源码不依赖作者电脑的固定绝对路径，不使用符号链接。

## 先看哪些文件

- `entries/common.js`：引入 React、React Native 的 AppRegistry 和共享模块。Metro 会沿静态依赖构建公共模块图。
- `entries/home.js`、`entries/profile.js`：两个 RN 页面，各自注册不同的 AppRegistry 名称。
- `entries/shared.js`：共享对象及模块工厂执行计数，用来验证多个业务包引用同一份模块实例。
- `entries/smoke.js`：只依赖共享模块的最小验证入口，不渲染 RN。
- `scripts/build-shared-bundles.cjs`：先构建 common，再构建排除公共模块的业务包，最后生成完整独立包作为对照。

## 构建约束

1. `createModuleIdFactory` 根据规范化相对路径生成确定的整数 ID，并检查哈希碰撞。公共包与业务包必须使用相同规则。
2. `processModuleFilter` 收集公共包包含的路径，并在业务包输出中排除这些模块。它只过滤输出，Metro 仍需要遍历业务依赖图，因此这不代表构建耗时会按体积同比下降。
3. 业务包设置 `modulesOnly: true`，不重复输出 Metro prelude/polyfills。
4. 业务包的 `getModulesRunBeforeMainModule` 返回空数组，不重复执行默认的 `react-native/setup-env`。它仍保留自己的入口执行语句。
5. 公共包必须先在**同一个 JS runtime**中执行，随后执行业务包。业务包不能单独运行，也不能直接装进另一个独立 RCTReactNativeFactory 当成完整包。
6. 生产发布还需要公共包/业务包版本配对、ID 清单持久化、资源处理、完整性校验、加载完成通知与失败回退；本例没有实现这些工程能力。

`Metro.runBuild` 不直接透传 `modulesOnly`。为明确控制该选项，本例使用 `Metro.runMetro` 创建 Server，再调用 `server.build`，并从 `metro/private/Server` 读取默认构建选项。这些属于与 Metro 版本相关的构建接口，升级时需要核对。

## 实际验证范围

脚本使用真实 Metro 输出和真实 Metro 的 `__d`/`__r` 模块系统，在 Node `vm` 中验证：

- 没有 common 时，业务增量包因缺少 `__d` 无法启动。
- 先装载 common 的模块定义，再执行 smoke 业务包，得到 `Hello Metro`。
- 业务包不会替换 Metro 的 `__r`。
- 重复评估 smoke 包后，共享模块的工厂仍只执行一次，导出的对象仍是同一实例。
- 业务输出没有重复包含 common 的模块。

**VM 验证专门跳过 common 末尾的 RN 启动语句。** Node 没有 iOS TurboModule、Fabric 和 Hermes 环境。它验证的是 Metro 模块定义、依赖 ID 与缓存语义，不证明 common 在原生初始化成功，不证明 RN 页面已经在 iOS 上渲染，也不测量启动性能。

## 一次真实测量

在 Node 22.22.0、React Native 0.88.1、React 19.3.0、Metro 0.87.2 下，以 `platform=ios`、`dev=false`、`minify=true` 构建。数字是未压缩 JavaScript 源码 bundle 的字节数，不是 Hermes bytecode、下载压缩包、IPA 大小或内存占用：

| 产物 | 字节数 | 模块定义数 |
| --- | ---: | ---: |
| common.ios.jsbundle | 892630 | 515 |
| home.ios.jsbundle | 376 | 1 |
| profile.ios.jsbundle | 379 | 1 |
| home.full.ios.jsbundle | 892766 | 515 |
| profile.full.ios.jsbundle | 892769 | 515 |

两个独立完整包合计 **1785535 B**；公共包与两个业务包合计 **893385 B**，在这两个极小业务页面的例子中减少 **49.97%**。这是公共代码占比很高的示范，不能推广成任意项目的收益。

`dist/stats.json` 记录本机运行的结果；`dist/module-ids.json` 便于核对 ID。依赖版本不同，输出数字可能变化。

## iOS 新架构的连接点与限制

基于已安装 RN 0.88.1 源码：

- `RCTHost.h` 暴露启动、创建 surface、调用 JS 模块等能力，没有面向业务的“追加 bundle 并等待完成”方法。
- `RCTHostDelegate` 的 `loadBundleAtURL:onProgress:onComplete:` 是主 bundle 的**源码加载回调**。默认交给 `RCTJavaScriptLoader` 下载或读取代码，并非把任意第二个包评估进 runtime。
- 公开的 `host:didInitializeRuntime:` 钩子在 JS 线程、原生绑定安装后、主 bundle 执行前得到 `jsi::Runtime&`。它可以用于定制运行时能力；它不是启动后追加 bundle 的完整业务接口。不能把 runtime 引用拿到任意线程调用。
- `RCTHost+Internal.h` 的 `registerSegmentWithId:path:` 会通向 `ReactInstance::registerSegment`，后者调度到 runtime 并调用 `runtime.evaluateJavaScript`。但入口属于 Internal，且没有向业务暴露评估完成回调。本例未接入它，也未验证其 iOS 行为。
- C++ `ReactInstance::loadScript` 与 `RCTInstance` 的 buffered executor 也在源码中，但 `RCTInstance.h` 明确要求产品代码通过 RCTHost 管理实例，不能直接创建实例绕开生命周期。

因此，想把此实验升级成 iOS 共享 runtime 拆包，需要针对 RN 版本实现原生加载适配，明确线程、顺序、注册完成与容错。本目录没有把这个缺口包装成“可直接运行的原生拆包方案”。
