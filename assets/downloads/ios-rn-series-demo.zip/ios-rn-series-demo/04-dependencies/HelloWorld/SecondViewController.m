// SecondViewController.m
#import "SecondViewController.h"
#import <Masonry/Masonry.h>

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"第二页";
    self.view.backgroundColor = UIColor.systemBackgroundColor;

    UILabel *label = [[UILabel alloc] init];
    label.text = @"这是第二个原生页面";
    label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle2];
    label.adjustsFontForContentSizeCategory = YES;
    label.numberOfLines = 0;

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"返回首页" forState:UIControlStateNormal];
    [button addTarget:self
               action:@selector(goBack)
     forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:label];
    [self.view addSubview:button];

    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop).offset(48);
        make.left.equalTo(self.view.mas_safeAreaLayoutGuideLeft).offset(24);
        make.right.equalTo(self.view.mas_safeAreaLayoutGuideRight).offset(-24);
    }];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(label.mas_bottom).offset(32);
        make.leading.trailing.equalTo(label);
        make.height.mas_equalTo(48);
    }];
}

- (void)goBack {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
