// HelloWorldViewController.m
#import "HelloWorldViewController.h"
#import <Masonry/Masonry.h>
#import "SecondViewController.h"

@implementation HelloWorldViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"iOS 学习 Demo";
    self.view.backgroundColor = UIColor.systemBackgroundColor;

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = @"Hello World";
    titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleLargeTitle];
    titleLabel.adjustsFontForContentSizeCategory = YES;
    titleLabel.numberOfLines = 0;

    UILabel *descriptionLabel = [[UILabel alloc] init];
    descriptionLabel.text = @"这是一个原生 UIKit 页面。点击按钮，进入第二页。";
    descriptionLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    descriptionLabel.adjustsFontForContentSizeCategory = YES;
    descriptionLabel.numberOfLines = 0;
    descriptionLabel.textColor = UIColor.secondaryLabelColor;

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"打开第二页" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [button addTarget:self
               action:@selector(openSecondPage)
     forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:titleLabel];
    [self.view addSubview:descriptionLabel];
    [self.view addSubview:button];

    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop).offset(48);
        make.left.equalTo(self.view.mas_safeAreaLayoutGuideLeft).offset(24);
        make.right.equalTo(self.view.mas_safeAreaLayoutGuideRight).offset(-24);
    }];
    [descriptionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(titleLabel.mas_bottom).offset(16);
        make.leading.trailing.equalTo(titleLabel);
    }];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(descriptionLabel.mas_bottom).offset(32);
        make.leading.trailing.equalTo(titleLabel);
        make.height.mas_equalTo(48);
    }];
}

- (void)openSecondPage {
    SecondViewController *second = [[SecondViewController alloc] init];
    [self.navigationController pushViewController:second animated:YES];
}

@end
