#!/bin/bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"
command -v pod >/dev/null || { echo "请先安装 CocoaPods，确认 pod 命令可用。"; exit 1; }
pod install
echo "依赖已安装，打开 HelloWorld.xcworkspace 或执行 ./run.sh。"
