# CocoaPods 与 Masonry（第 4 篇）

与 03-native 保持相同的两个页面和导航行为，使用 Masonry 1.1.0 表达布局约束。本阶段没有 RN、Node.js 配置或 JS 构建步骤。

## 环境与运行

需要 macOS、完整 Xcode、已安装的 iOS Simulator runtime、CocoaPods。运行脚本还使用 python3。App 的最低部署版本为 iOS 15.1。

```bash
./setup.sh
open HelloWorld.xcworkspace
```

setup.sh 执行 pod install，根据 Podfile.lock 安装依赖并生成 Pods 工程与 workspace。首次安装需要联网。在 Xcode 选择 HelloWorld Scheme 和 iPhone 模拟器，按 Command-R。

也可直接编译、安装并启动模拟器 App：

```bash
./run.sh
# 指定模拟器：
./run.sh 模拟器UDID
```

run.sh 会先执行 setup.sh。构建日志保存在 build/build.log。不要在接入 Pods 后继续用 xcodeproj 运行应用。

## 对照文章

HelloWorldViewController.m 和 SecondViewController.m 引入 Masonry/Masonry.h，并用 mas_makeConstraints 创建约束。Masonry 负责表达约束，计算布局的仍是 Auto Layout。

Podfile 固定 Masonry 1.1.0，Podfile.lock 保存完整依赖解析结果。Pods/ 是安装产物，不包含在示例压缩包中。最低部署版本在 post_install 中统一，避免旧依赖声明的过低版本触发工具链警告。

仅编译、不安装或启动 UI：

```bash
./setup.sh
xcodebuild -workspace HelloWorld.xcworkspace -scheme HelloWorld \
  -configuration Debug -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath build/DerivedData CODE_SIGNING_ALLOWED=NO build
```
