import type {TurboModule} from 'react-native';
import {TurboModuleRegistry} from 'react-native';

export type AppInfo = {
  appName: string;
  systemVersion: string;
  receivedMessage: string;
};

// 这是 JS 与 iOS 约定的接口。Codegen 根据它生成原生接口，
// RCTNativeDemo.mm 实现具体方法，React 页面可以像调用异步 JS 方法一样使用。
export interface Spec extends TurboModule {
  getAppInfo(message: string): Promise<AppInfo>;
}

export default TurboModuleRegistry.getEnforcing<Spec>('NativeDemo');
