# 05-rn：单 bundle 的 iOS 与 React Native Demo

这个目录对应系列第 5—7 篇的完整代码：UIKit 首页、原生第二页、RN 页面，以及 NativeDemo 原生通信。

## 环境

需要 macOS、Xcode 与可用的 iOS Simulator runtime、CocoaPods、Python 3，以及符合 package.json engines 的 Node。
本阶段锁定 React Native 0.88.1、React 19.3.0，iOS deployment target 为 15.1。

## 安装和运行

```bash
./setup.sh
./run.sh
```

默认构建并运行 Debug，JavaScript 随 App 内置，不需要先启动 Metro。从首页点击“打开 RN 页面”，可以查看原生传参、React 计数器，并点击“调用 iOS 方法”。

需要 Fast Refresh：

```bash
./run.sh --metro
```

运行 Release：

```bash
./run.sh --release
```

也可以执行 `open HelloWorld.xcworkspace`，选择 HelloWorld scheme 和 iPhone 模拟器后运行。
`setup.sh` 负责 npm 安装、Pods 集成与 Codegen，并为本机生成 `.xcode.env.local`。不要复制其他电脑生成的 Node 路径。
构建日志位于 `build/build.log`，Metro 日志位于 `build/metro.log`。

## 校验

```bash
npm run typecheck
```

修改原生文件或 Codegen spec 后，需要重新安装必要依赖并编译 App。默认离线模式修改 JS 后也需要重新构建。
