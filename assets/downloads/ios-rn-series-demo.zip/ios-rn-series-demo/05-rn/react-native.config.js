module.exports = {
  project: {
    // 这个教学项目的 Podfile 和 xcodeproj 位于根目录，没有额外的 ios/ 层。
    ios: {sourceDir: '.'},
  },
};
