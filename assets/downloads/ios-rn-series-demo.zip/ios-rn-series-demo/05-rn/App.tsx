import React, {useEffect, useRef, useState} from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';
import NativeDemo, {type AppInfo} from './specs/NativeDemo';

type AppProps = {
  greeting?: string;
  source?: string;
};

// iOS 创建页面时传入的 initialProps，会成为这个组件的 React props。
// 窗口、顶部导航栏和返回动作仍由原生 UIKit 管理。
export default function App({
  greeting = '你好，React Native',
  source = 'iOS',
}: AppProps) {
  const isDark = useColorScheme() === 'dark';
  const colors = isDark ? darkColors : lightColors;
  const [count, setCount] = useState(0);
  const [appInfo, setAppInfo] = useState<AppInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isMounted = useRef(false);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      // 用户从原生导航栏返回后，不再向已卸载的页面写入异步结果。
      isMounted.current = false;
    };
  }, []);

  async function requestAppInfo() {
    if (loading) {
      return;
    }
    setLoading(true);
    setError(null);

    try {
      // 调用会跨到 iOS 的 RCTNativeDemo 实现，再通过 Promise 返回结果。
      const result = await NativeDemo.getAppInfo('你好，来自 RN');
      if (isMounted.current) {
        setAppInfo(result);
      }
    } catch (cause) {
      if (isMounted.current) {
        setError(cause instanceof Error ? cause.message : '调用 iOS 方法失败');
      }
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  }

  return (
    <ScrollView
      style={[styles.page, {backgroundColor: colors.background}]}
      contentContainerStyle={styles.content}
      contentInsetAdjustmentBehavior="never">
      <View style={styles.header}>
        <Text
          accessibilityRole="header"
          testID="hello-rn-title"
          style={[styles.title, {color: colors.text}]}>
          Hello React Native
        </Text>
        <Text style={[styles.body, {color: colors.secondaryText}]}>
          这是写在 React 里的页面，运行在你的 iOS App 中。
        </Text>
      </View>

      <View
        style={[
          styles.card,
          {backgroundColor: colors.card, borderColor: colors.border},
        ]}>
        <Text style={[styles.cardTitle, {color: colors.text}]}>
          iOS 传来的参数
        </Text>
        <Text testID="rn-greeting" style={[styles.body, {color: colors.text}]}>
          {greeting}
        </Text>
        <Text style={[styles.caption, {color: colors.secondaryText}]}>
          来源：{source}
        </Text>
      </View>

      <View
        style={[
          styles.card,
          {backgroundColor: colors.card, borderColor: colors.border},
        ]}>
        <Text style={[styles.cardTitle, {color: colors.text}]}>
          先试试 React 的交互
        </Text>
        <Text testID="rn-counter-value" style={[styles.body, {color: colors.text}]}>
          已点击 {count} 次
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="计数加一"
          testID="rn-counter-button"
          onPress={() => setCount(value => value + 1)}
          style={({pressed}) => [
            styles.button,
            {backgroundColor: colors.accent, opacity: pressed ? 0.7 : 1},
          ]}>
          <Text style={styles.buttonText}>点击 +1</Text>
        </Pressable>
      </View>

      <View
        style={[
          styles.card,
          {backgroundColor: colors.card, borderColor: colors.border},
        ]}>
        <Text style={[styles.cardTitle, {color: colors.text}]}>
          再试试 RN 调用 iOS
        </Text>
        <Text style={[styles.body, {color: colors.secondaryText}]}>
          把一句问候发送给 iOS，并取回 App 名称和系统版本。
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityState={{disabled: loading, busy: loading}}
          testID="rn-native-button"
          disabled={loading}
          onPress={requestAppInfo}
          style={({pressed}) => [
            styles.button,
            {
              backgroundColor: colors.accent,
              opacity: loading || pressed ? 0.7 : 1,
            },
          ]}>
          {loading ? <ActivityIndicator color="#FFFFFF" /> : null}
          <Text style={styles.buttonText}>
            {loading ? '正在等待 iOS…' : '调用 iOS 方法'}
          </Text>
        </Pressable>
        {appInfo ? (
          <Text
            accessibilityLiveRegion="polite"
            testID="rn-native-result"
            style={[styles.body, {color: colors.text}]}>
            {`App：${appInfo.appName}\niOS：${appInfo.systemVersion}\niOS 收到：${appInfo.receivedMessage}`}
          </Text>
        ) : null}
        {error ? (
          <Text
            accessibilityRole="alert"
            testID="rn-native-error"
            style={[styles.body, {color: colors.error}]}>
            {error}
          </Text>
        ) : null}
      </View>
    </ScrollView>
  );
}

const lightColors = {
  background: '#F3F5FA',
  card: '#FFFFFF',
  border: '#E0E5EF',
  text: '#17243A',
  secondaryText: '#5B667A',
  accent: '#245AD4',
  error: '#B42318',
};

const darkColors = {
  background: '#10141D',
  card: '#1C2432',
  border: '#354055',
  text: '#F3F5FA',
  secondaryText: '#B6C2D6',
  accent: '#245AD4',
  error: '#FFB4AB',
};

const styles = StyleSheet.create({
  page: {flex: 1},
  content: {padding: 20, gap: 16},
  header: {gap: 8},
  title: {fontSize: 28, fontWeight: '700'},
  card: {padding: 18, gap: 12, borderWidth: 1, borderRadius: 16},
  cardTitle: {fontSize: 18, fontWeight: '600'},
  body: {fontSize: 16, lineHeight: 24},
  caption: {fontSize: 14, lineHeight: 21},
  button: {
    minHeight: 48,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  buttonText: {color: '#FFFFFF', fontSize: 16, fontWeight: '600', textAlign: 'center'},
});
