import {AppRegistry} from 'react-native';
import App from './App';

// 注册名必须与 iOS 创建 RN 页面时的 moduleName（HelloRN）完全一致。
// iOS 通过这个名字找到要展示的 React 组件。
AppRegistry.registerComponent('HelloRN', () => App);
