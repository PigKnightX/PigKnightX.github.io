const {getDefaultConfig, mergeConfig} = require('@react-native/metro-config');

module.exports = mergeConfig(getDefaultConfig(__dirname), {
  server: {
    port: 8082,
    // 供运行脚本识别当前 Metro，避免误用其他项目已经占用的服务。
    enhanceMiddleware: middleware => (request, response, next) => {
      if (request.method === 'GET' && request.url === '/demo-project') {
        response.setHeader('Content-Type', 'application/json');
        response.end(JSON.stringify({name: 'ios-learn-demo', root: __dirname}));
        return;
      }
      return middleware(request, response, next);
    },
  },
});
