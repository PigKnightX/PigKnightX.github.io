#import "RNViewController.h"
#import "RNHost.h"
#import <Masonry/Masonry.h>

@implementation RNViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"RN 页面";
    self.view.backgroundColor = [UIColor systemBackgroundColor];

    NSDictionary *props = @{
        @"greeting": @"你好，这是 iOS 传给 RN 的问候",
        @"source": @"HelloWorld · UIKit"
    };
    UIView *reactView = [[RNHost sharedHost] viewWithModuleName:@"HelloRN"
                                          initialProperties:props];
    [self.view addSubview:reactView];
    [reactView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        make.left.equalTo(self.view.mas_safeAreaLayoutGuideLeft);
        make.right.equalTo(self.view.mas_safeAreaLayoutGuideRight);
    }];
}

@end
