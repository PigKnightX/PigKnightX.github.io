#import "HelloWorldViewController.h"
#import "SecondViewController.h"
#import "RNViewController.h"
// import 引入 Masonry 的声明，下面就可以使用它的布局方法。
#import <Masonry/Masonry.h>

@implementation HelloWorldViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"[启动] 5. HelloWorldViewController：创建页面内容");
    self.title = @"首页";
    self.navigationItem.backButtonTitle = @"首页";

    // ⑤ UIView 是页面画布；系统颜色会自动适配浅色和深色模式。
    self.view.backgroundColor = [UIColor systemBackgroundColor];

    // 透明容器贴合安全区域，让里面的文字避开刘海和底部手势区。
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:contentView];

    // mas_makeConstraints 创建 Auto Layout 约束；equalTo 表示与目标对齐。
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        make.left.equalTo(self.view.mas_safeAreaLayoutGuideLeft);
        make.right.equalTo(self.view.mas_safeAreaLayoutGuideRight);
    }];

    // UILabel 是放在页面上的一块“文字积木”。
    UILabel *label = [[UILabel alloc] init];
    label.text = @"Hello world";
    label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleLargeTitle];
    label.adjustsFontForContentSizeCategory = YES;
    label.textColor = [UIColor labelColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.accessibilityIdentifier = @"hello-world-label";
    [contentView addSubview:label];

    // centerX / centerY 约束横纵中心；两边至少留 24pt。
    // 大字号或横屏时，允许文字上移，为下方按钮留出空间。
    // Masonry 会自动关闭 autoresizing mask 转换，不需要手动设置。
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(contentView);
        make.centerY.equalTo(contentView).offset(-40.0).priorityHigh();
        make.top.greaterThanOrEqualTo(contentView.mas_top).offset(24.0);
        make.leading.greaterThanOrEqualTo(contentView.mas_leading).offset(24.0);
        make.trailing.lessThanOrEqualTo(contentView.mas_trailing).offset(-24.0);
    }];

    // UIButton 是可以点击的“按钮积木”；点击后执行 openSecondPage。
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"打开第二页" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    button.titleLabel.adjustsFontForContentSizeCategory = YES;
    button.titleLabel.numberOfLines = 0;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.accessibilityIdentifier = @"open-second-page-button";
    [button addTarget:self action:@selector(openSecondPage) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:button];

    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(label.mas_bottom).offset(24.0);
        make.centerX.equalTo(contentView);
        make.leading.greaterThanOrEqualTo(contentView.mas_leading).offset(24.0);
        make.trailing.lessThanOrEqualTo(contentView.mas_trailing).offset(-24.0);
        make.height.greaterThanOrEqualTo(@44.0);
        make.bottom.lessThanOrEqualTo(contentView.mas_bottom).offset(-24.0);
    }];

    // RN 页面也先装进一个原生 ViewController，再由同一个导航控制器打开。
    UIButton *rnButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [rnButton setTitle:@"打开 RN 页面" forState:UIControlStateNormal];
    rnButton.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    rnButton.titleLabel.adjustsFontForContentSizeCategory = YES;
    rnButton.titleLabel.numberOfLines = 0;
    rnButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    rnButton.accessibilityIdentifier = @"open-rn-page-button";
    [rnButton addTarget:self action:@selector(openRNPage) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:rnButton];
    [rnButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(button.mas_bottom).offset(16.0);
        make.centerX.equalTo(contentView);
        make.leading.greaterThanOrEqualTo(contentView.mas_leading).offset(24.0);
        make.trailing.lessThanOrEqualTo(contentView.mas_trailing).offset(-24.0);
        make.height.greaterThanOrEqualTo(@44.0);
        make.bottom.lessThanOrEqualTo(contentView.mas_bottom).offset(-24.0);
    }];


}

- (void)openRNPage {
    RNViewController *rnPage = [[RNViewController alloc] init];
    [self.navigationController pushViewController:rnPage animated:YES];
}


- (void)openSecondPage {
    SecondViewController *secondPage = [[SecondViewController alloc] init];
    // push：把新页面放到导航栈顶，首页仍留在下面，方便返回。
    [self.navigationController pushViewController:secondPage animated:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"[启动] 6. HelloWorldViewController：页面已显示");
}

@end
