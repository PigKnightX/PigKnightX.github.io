#import <Foundation/Foundation.h>
#import <DemoSpec/DemoSpec.h>

// NativeDemoSpec 来自 specs/NativeDemo.ts，经 pod install 时的 Codegen 生成。
@interface RCTNativeDemo : NSObject <NativeDemoSpec>
@end
