#import "RNHost.h"
#import <React/RCTBundleURLProvider.h>
#import <React/RCTBundleManager.h>
#import <React/RCTDevMenu.h>
#import <React-RCTAppDelegate/RCTDefaultReactNativeFactoryDelegate.h>
#import <React-RCTAppDelegate/RCTReactNativeFactory.h>
#import <ReactAppDependencyProvider/RCTAppDependencyProvider.h>

@interface DemoReactNativeDelegate : RCTDefaultReactNativeFactoryDelegate
@end

@implementation DemoReactNativeDelegate
- (NSURL *)bundleURL {
#if DEBUG
    if ([[NSProcessInfo processInfo].environment[@"RN_USE_METRO"]
         isEqualToString:@"1"]) {
        return [RCTBundleURLProvider jsBundleURLForBundleRoot:@"index"
            packagerHost:@"localhost:8082"
            enableDev:YES enableMinification:NO inlineSourceMap:NO];
    }
#endif
    return [[NSBundle mainBundle] URLForResource:@"main"
                                  withExtension:@"jsbundle"];
}

- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge {
    return [self bundleURL];
}
@end

@interface RNHost ()
@property (nonatomic, strong) DemoReactNativeDelegate *delegate;
@property (nonatomic, strong) RCTReactNativeFactory *factory;
@property (nonatomic, strong) RCTBundleConfiguration *bundleConfiguration;
@property (nonatomic, strong) RCTDevMenuConfiguration *devMenuConfiguration;
@end

@implementation RNHost
+ (instancetype)sharedHost {
    static RNHost *host;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ host = [[RNHost alloc] init]; });
    return host;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        BOOL usesMetro = NO;
#if DEBUG
        usesMetro = [[NSProcessInfo processInfo].environment[@"RN_USE_METRO"]
                     isEqualToString:@"1"];
#endif
        RCTBundleURLProviderAllowPackagerServerAccess(usesMetro);
        _delegate = [[DemoReactNativeDelegate alloc] init];
        _delegate.dependencyProvider = [[RCTAppDependencyProvider alloc] init];
        _factory = [[RCTReactNativeFactory alloc] initWithDelegate:_delegate];

        NSURL *url = [_delegate bundleURL];
        if (url.isFileURL) {
            _bundleConfiguration = [[RCTBundleConfiguration alloc]
                initWithBundleFilePath:url];
        } else {
            _bundleConfiguration = [[RCTBundleConfiguration alloc]
                initWithPackagerServerScheme:@"http"
                packagerServerHost:@"localhost:8082" bundlePath:@"index"];
        }
#if DEBUG
        _devMenuConfiguration = [[RCTDevMenuConfiguration alloc]
            initWithDevMenuEnabled:usesMetro shakeGestureEnabled:usesMetro
            keyboardShortcutsEnabled:usesMetro];
#else
        _devMenuConfiguration = [RCTDevMenuConfiguration defaultConfiguration];
#endif
    }
    return self;
}

- (UIView *)viewWithModuleName:(NSString *)moduleName
            initialProperties:(NSDictionary *)initialProperties {
    return [self.factory.rootViewFactory viewWithModuleName:moduleName
        initialProperties:initialProperties launchOptions:nil
        bundleConfiguration:self.bundleConfiguration
        devMenuConfiguration:self.devMenuConfiguration];
}
@end
