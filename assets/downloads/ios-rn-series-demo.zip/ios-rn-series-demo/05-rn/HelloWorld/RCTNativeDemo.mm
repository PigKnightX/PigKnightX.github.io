#import "RCTNativeDemo.h"
#import <UIKit/UIKit.h>

@implementation RCTNativeDemo

// JS 通过 TurboModuleRegistry.getEnforcing('NativeDemo') 找到这个模块。
RCT_EXPORT_MODULE(NativeDemo)

+ (BOOL)requiresMainQueueSetup {
    return NO;
}

- (void)getAppInfo:(NSString *)message
           resolve:(RCTPromiseResolveBlock)resolve
            reject:(RCTPromiseRejectBlock)reject {
    // RN → iOS：JS 的字符串参数传进来；原生执行后用 resolve 返回 Promise 结果。
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *appName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];
        NSDictionary *result = @{
            @"appName": appName ?: @"Hello World",
            @"systemVersion": [UIDevice currentDevice].systemVersion,
            @"receivedMessage": message
        };
        NSLog(@"[RN → iOS] NativeDemo.getAppInfo 收到：%@", message);
        resolve(result);
    });
}

- (std::shared_ptr<facebook::react::TurboModule>)getTurboModule:
    (const facebook::react::ObjCTurboModule::InitParams &)params {
    // Codegen 生成的适配层负责连接 JS 调用和上面的 Objective-C 方法。
    return std::make_shared<facebook::react::NativeDemoSpecJSI>(params);
}

@end
