#import <UIKit/UIKit.h>

// 原生导航栈中的页面，内容区域由 React Native 渲染。
@interface RNViewController : UIViewController
@end
