#import "SecondViewController.h"
#import <Masonry/Masonry.h>

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"第二页";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    NSLog(@"[导航] SecondViewController：创建第二页内容");

    // 和首页一样，内容放在安全区域内，避开导航栏与底部手势区。
    UIView *contentView = [[UIView alloc] init];
    [self.view addSubview:contentView];
    [contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_safeAreaLayoutGuideTop);
        make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        make.left.equalTo(self.view.mas_safeAreaLayoutGuideLeft);
        make.right.equalTo(self.view.mas_safeAreaLayoutGuideRight);
    }];

    UILabel *label = [[UILabel alloc] init];
    label.text = @"这是第二个页面";
    label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
    label.adjustsFontForContentSizeCategory = YES;
    label.textColor = [UIColor labelColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    label.accessibilityIdentifier = @"second-page-label";
    [contentView addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(contentView);
        // 大字号或横屏时，允许内容向上移动，为下方说明和按钮留出空间。
        make.centerY.equalTo(contentView).offset(-48.0).priorityHigh();
        make.top.greaterThanOrEqualTo(contentView.mas_top).offset(24.0);
        make.leading.greaterThanOrEqualTo(contentView.mas_leading).offset(24.0);
        make.trailing.lessThanOrEqualTo(contentView.mas_trailing).offset(-24.0);
    }];

    UILabel *descriptionLabel = [[UILabel alloc] init];
    descriptionLabel.text = @"这是一个独立的 ViewController。";
    descriptionLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    descriptionLabel.adjustsFontForContentSizeCategory = YES;
    descriptionLabel.textColor = [UIColor secondaryLabelColor];
    descriptionLabel.textAlignment = NSTextAlignmentCenter;
    descriptionLabel.numberOfLines = 0;
    [contentView addSubview:descriptionLabel];
    [descriptionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(label.mas_bottom).offset(16.0);
        make.leading.equalTo(contentView.mas_leading).offset(24.0);
        make.trailing.equalTo(contentView.mas_trailing).offset(-24.0);
    }];

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:@"返回首页" forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    button.titleLabel.adjustsFontForContentSizeCategory = YES;
    button.titleLabel.numberOfLines = 0;
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    button.accessibilityIdentifier = @"back-home-button";
    [button addTarget:self action:@selector(backToHome) forControlEvents:UIControlEventTouchUpInside];
    [contentView addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(descriptionLabel.mas_bottom).offset(24.0);
        make.centerX.equalTo(contentView);
        make.leading.greaterThanOrEqualTo(contentView.mas_leading).offset(24.0);
        make.trailing.lessThanOrEqualTo(contentView.mas_trailing).offset(-24.0);
        make.height.greaterThanOrEqualTo(@44.0);
        make.bottom.lessThanOrEqualTo(contentView.mas_bottom).offset(-24.0);
    }];
}

- (void)backToHome {
    // pop：移除栈顶的第二页，显示下面原来的首页。
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"[导航] SecondViewController：第二页已显示");
}

- (void)dealloc {
    NSLog(@"[导航] SecondViewController：第二页已释放");
}

@end
