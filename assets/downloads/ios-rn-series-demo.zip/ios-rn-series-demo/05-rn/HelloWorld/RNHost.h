#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// App 共用的 RN 运行环境；每个 RN 页面只向它申请一块 UIView。
@interface RNHost : NSObject

+ (instancetype)sharedHost;
- (UIView *)viewWithModuleName:(NSString *)moduleName
            initialProperties:(nullable NSDictionary *)initialProperties;

@end

NS_ASSUME_NONNULL_END
