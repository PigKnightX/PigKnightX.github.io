#!/bin/bash
# 默认运行内置 JS 的 Debug；--metro 开启前端开发模式；--release 运行生产包。
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
mkdir -p "$BUILD_DIR"

CONFIGURATION=Debug
USE_METRO=0
REQUESTED_DEVICE=""
MODE_SELECTED=0
for argument in "$@"; do
    case "$argument" in
        --metro|--release)
            if [[ "$MODE_SELECTED" == 1 ]]; then
                echo "--metro 和 --release 只能选择一个。"
                exit 1
            fi
            MODE_SELECTED=1
            if [[ "$argument" == --metro ]]; then USE_METRO=1; else CONFIGURATION=Release; fi
            ;;
        --help|-h)
            echo "用法：./run.sh [--metro | --release] [模拟器UDID]"
            exit 0
            ;;
        --*) echo "未知选项：$argument"; exit 1 ;;
        *)
            if [[ -n "$REQUESTED_DEVICE" ]]; then echo "只能指定一个模拟器。"; exit 1; fi
            REQUESTED_DEVICE="$argument"
            ;;
    esac
done

"$PROJECT_DIR/setup.sh" --if-needed

if [[ "$USE_METRO" == 1 ]]; then
    # 确认服务属于这个 Demo，不能把其他项目的 Metro 当成自己的。
    metro_is_ours() {
        curl --fail --silent --max-time 2 http://127.0.0.1:8082/demo-project |
            python3 -c 'import json,os,sys; data=json.load(sys.stdin); sys.exit(0 if data.get("name")=="ios-learn-demo" and os.path.realpath(data.get("root",""))==os.path.realpath(sys.argv[1]) else 1)' "$PROJECT_DIR" 2>/dev/null
    }
    if ! metro_is_ours; then
        if lsof -nP -iTCP:8082 -sTCP:LISTEN >/dev/null 2>&1; then
            echo "8082 已被其他服务占用。请先处理占用，再运行；本脚本不会终止其他服务。"
            exit 1
        fi
        echo "正在启动 Metro（日志：$BUILD_DIR/metro.log）……"
        # 单独的进程会话让 Metro 在运行脚本结束后继续提供 Fast Refresh。
        python3 - "$PROJECT_DIR" "$BUILD_DIR" <<'PY'
from pathlib import Path
import subprocess
import sys
project_dir, build_dir = sys.argv[1:]
with open(Path(build_dir) / 'metro.log', 'w') as output:
    server = subprocess.Popen(
        ['npm', 'start'], cwd=project_dir, stdin=subprocess.DEVNULL,
        stdout=output, stderr=subprocess.STDOUT, start_new_session=True,
    )
Path(build_dir, 'metro.pid').write_text(str(server.pid) + '\n')
PY
        READY=0
        for attempt in {1..30}; do
            if metro_is_ours; then READY=1; break; fi
            sleep 1
        done
        if [[ "$READY" != 1 ]]; then
            tail -n 40 "$BUILD_DIR/metro.log"
            echo "Metro 未能启动，请查看上面的日志。"
            exit 1
        fi
    fi
fi

# 优先使用已启动的 iPhone；否则选择已安装的最新 iOS 中的 iPhone。
xcrun simctl list devices available --json > "$BUILD_DIR/devices.json"
DEVICE_ID="$(python3 - "$BUILD_DIR/devices.json" "$REQUESTED_DEVICE" <<'PY'
import json
import re
import sys

with open(sys.argv[1]) as stream:
    groups = json.load(stream)["devices"]
requested = sys.argv[2]
candidates = []
for runtime, devices in groups.items():
    if ".iOS-" not in runtime:
        continue
    version = tuple(map(int, re.findall(r"\d+", runtime.rsplit("iOS-", 1)[1])))
    for device in devices:
        if not device.get("isAvailable", False):
            continue
        if requested:
            if device["udid"] == requested:
                print(requested)
                sys.exit(0)
        elif device["name"].startswith("iPhone"):
            candidates.append((device["state"] == "Booted", version, device))
if requested:
    sys.exit("找不到这个可用的 iOS 模拟器：" + requested)
if not candidates:
    sys.exit("没有可用的 iPhone 模拟器，请先在 Xcode 中安装 iOS Simulator runtime。")
candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
print(candidates[0][2]["udid"])
PY
)"

echo "正在编译 HelloWorld ${CONFIGURATION}（日志：$BUILD_DIR/build.log）……"
if ! xcodebuild \
    -workspace "$PROJECT_DIR/HelloWorld.xcworkspace" \
    -scheme HelloWorld \
    -configuration "$CONFIGURATION" \
    -sdk iphonesimulator \
    -destination "platform=iOS Simulator,id=$DEVICE_ID" \
    -derivedDataPath "$BUILD_DIR/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    build > "$BUILD_DIR/build.log" 2>&1; then
    tail -n 60 "$BUILD_DIR/build.log"
    exit 1
fi

# Xcode 27 用 Device Hub 展示模拟器；旧版 Xcode 使用 Simulator。
# 先启动界面工具，让模拟器服务准备好，再启动设备。
DEVELOPER_DIR_PATH="$(xcode-select -p)"
DEVICE_HUB="$DEVELOPER_DIR_PATH/../Applications/DeviceHub.app"
if [[ -d "$DEVICE_HUB" ]]; then
    open "$DEVICE_HUB"
else
    open -a Simulator
fi

echo "正在启动模拟器：$DEVICE_ID"
xcrun simctl bootstatus "$DEVICE_ID" -b

APP_PATH="$BUILD_DIR/DerivedData/Build/Products/$CONFIGURATION-iphonesimulator/HelloWorld.app"
xcrun simctl install "$DEVICE_ID" "$APP_PATH"
SIMCTL_CHILD_RN_USE_METRO="$USE_METRO" xcrun simctl launch --terminate-running-process "$DEVICE_ID" com.example.ioslearndemo
echo "已启动 HelloWorld：点击首页的“打开 RN 页面”。"
if [[ "$USE_METRO" == 1 ]]; then
    echo "当前为 Metro 开发模式；修改 App.tsx 可以通过 Fast Refresh 查看变化。"
else
    echo "当前使用 App 内置的 JavaScript；修改 App.tsx 后重新编译即可。"
fi
