#!/bin/bash
# 首次安装：npm 下载 JS/RN 源码，CocoaPods 接入 iOS 原生依赖并运行 Codegen。
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"
mkdir -p build

for tool in node npm pod python3; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "缺少 ${tool}，请按 README 的环境准备说明安装。"
        exit 1
    fi
done

# run.sh 可以复用已经安装且与锁文件一致的 node_modules。
INSTALL_NODE=1
if [[ "${1:-}" == "--if-needed" && -f node_modules/react-native/package.json && -f package-lock.json && -f build/npm-inputs.sha256 ]]; then
    if shasum -a 256 package.json package-lock.json | cmp -s - build/npm-inputs.sha256; then
        INSTALL_NODE=0
    fi
fi
if [[ "$INSTALL_NODE" == 1 ]]; then
    echo "正在安装 JavaScript 依赖……"
    if [[ -f package-lock.json ]]; then
        npm ci --no-audit --no-fund
    else
        npm install --no-audit --no-fund
    fi
    shasum -a 256 package.json package-lock.json > build/npm-inputs.sha256
fi

# Xcode 从图形界面启动时不一定加载 nvm；把本机 Node 的绝对路径交给构建脚本。
python3 - <<'PY'
from pathlib import Path
import shlex
import shutil
Path('.xcode.env.local').write_text(
    '# 本机专用，由 setup.sh 生成，不提交到版本库。\n'
    'export NODE_BINARY=' + shlex.quote(shutil.which('node')) + '\n'
)
PY

echo "正在安装 iOS 依赖并生成原生接口……"
pod install
echo "依赖已准备好，可以打开 HelloWorld.xcworkspace 或执行 ./run.sh。"
